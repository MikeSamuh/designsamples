# Handoff: Ritualizer — 90-Day Team Sprint journey

## Overview
A simplified replacement for the Ritualizer phase overview and task screens. The earlier version showed the phase stepper, a "next task" card, the task list and a progress side panel, and much of it repeated. This design puts the whole journey (6 phases → task groups → tasks) in one vertical timeline on the left, with the phase intro or the open task on the right. The app menu auto-collapses to an icon rail.

## About the design files
The files in this bundle are **design references built in HTML**. They are prototypes that show the intended look and behaviour, not production code. Recreate them in the target codebase's existing framework and component patterns. `Ritualizer Journey.html` is a self-contained clickable prototype that opens in any browser. `Ritualizer Journey.dc.html` is the readable source; all markup and logic are in one file.

## Fidelity
**High fidelity.** Colours, type, spacing and interactions are final, with these exceptions:
- **Placeholder task copy:** task lists for Empathize → Close, and most of Discover, are placeholders. Only Prepare and the first Discover tasks came from the product.
- **Placeholder icons:** the menu icons are 1.5px-stroke outline placeholders. Use the product's real icon set.
- **Placeholder task body:** non-video tasks show a "Task content opens here" box.

## Layout (1440 × 900 reference frame)
```
| App menu 64px (240 on hover, overlays) | Main column                                      |
|                                        | Title bar: "90-Day Team Sprint" (26px Marcellus) |
|                                        |---------------------------------------------------|
|                                        | Journey list 320px | Content pane (fluid)         |
```
- **Page:** background `#000`.
- **Hairlines:** `rgba(255,255,255,.16)` on the menu's right edge, under the title bar, and between the list and the content.

### 1. App menu (left)
- **Collapsed:** 64px wide, background `#0A0A0B`.
  - The S mark (`assets/samuh-s-mark.jpg`, 40×40) sits at the top.
  - Below it, 20px outline icons, one per item: 90-Day Team Sprint (active), Org Journey, Lead Journey, Keeper Kit, Notifications.
  - At the bottom, above a hairline: a user avatar ("QM", 28px circle, magenta), an Admin icon (magenta), and `v.176` (12px, 50% white).
- **Expanded:** on mouse enter the menu expands to 240px over the content, with width transitioning over 180ms `cubic-bezier(.2,0,.2,1)`. The content does not reflow. It collapses on mouse leave.
  - The S mark becomes the full Samuh wordmark (96px) with "RITUALIZER" below it (13px, tracking .22em, magenta).
  - A team picker appears under the logo: 48px tall, 1px hairline border, 4px radius. It reads "Never Ontime" (12px, 50% white) over "People Operations ▾" (15px).
  - Labels appear beside the icons (15px). The active item has an `#1C1C20` background, magenta text and weight 600. Hover uses `rgba(255,255,255,.08)`.
  - The user row shows "QA Manager ▾" and the Admin row shows "ADMIN" (13px, tracking .22em, 600, magenta).

### 2. Journey list (320px, scrolls)
A vertical timeline. The line is 1px `#4394AF`, centred at x=33px, and runs unbroken from the first phase node to the last.

**Phase rows** — one per phase: Prepare, Discover, Empathize, Crystallize, Iterate, Close.
- **Layout:** padding 16/24/12/22, 2px left border (transparent unless selected).
- **Node:** 18px circle with a 2px `#4394AF` ring. Filled `#4394AF` when the phase is done, black otherwise.
- **Name:** Marcellus 19px/400. White when selected; 72% white for done or current; 50% white for upcoming.
- **Status:** "Done" on the right, 12px, 50% white, for closed phases only.
- **Selected phase:** row background `rgba(255,255,255,.08)` (tinted header only).
- **Expansion:** only the selected phase expands to show its task groups.

**Task groups** — used when a phase has more than one labelled group, as in Discover.
- **Panel:** each labelled group is a panel with background `#121214` and 8px radius. It sits at margin 10px 12px 4px 48px, so the timeline line passes to its left.
- **Header:** padding 12/14/6. Group name in Inter 15px/700 white, e.g. "Before the session" or "In the session". Right-aligned qualifier in Gilda Display 14px, 72% white: "on your own", or the date "Fri 4 Sep, 15:00".
- **Unlabelled groups:** a phase with a single group (Prepare) shows its tasks directly on the timeline, with no panel.

**Task rows**
- **Layout:** padding 10/22/10/24 on the timeline, 10/22/10/12 inside a panel.
- **Ring:** 14px, `box-sizing:border-box`, 2px `#4394AF` ring. Filled `#4394AF` when done, `#000` otherwise.
- **Title:** Inter 15px. Selected is white/600; done is 50% white; otherwise 72% white.
- **Duration:** right-aligned "5 min", 13px, 50% white.
- **Selected task:** background `#1C1C20` and a 2px magenta left border.
- **Hover:** `rgba(255,255,255,.08)`.

**Footer:** a "Book a coaching call →" link at the bottom, 15px, colour `#4394AF`.

### 3. Content pane
**Phase intro** (shown when a phase is clicked):
- **Layout:** vertically centred, 72px side padding.
- **Eyebrow:** e.g. "DISCOVER · WITH THE TEAM" (15px, tracking .22em, 600, magenta).
- **Headline:** Marcellus 40px, line-height 1.15, max-width 640. The second clause is in magenta, e.g. "Run TeamQ together. *Then read the results as one team.*"
- **Lede:** 17px, 72% white, max-width 560.
- **Optional stat:** "1/16" (32px, `#4394AF`) + "have taken TeamQ" (15px, 72% white).
- **Primary button (lg):** "Start" / "Review" / "Preview" with →, magenta fill, 4px radius.

**Task view:**
- **Layout:** padding 32px 56px.
- **Meta line:** "Video · 5 min" in Gilda Display 14px, 50% white.
- **Title:** Marcellus 28px.
- **Description:** 15px, 72% white.
- **Body:**
  - **Video tasks:** a 16:9 player (max-height 380, `#121214`, 12px radius) with a centred 64px play button.
  - **Other tasks:** a 280px placeholder panel.
- **Tabs** (only if the task has notes): "Key messages" | "Script". The active tab is white with a 2px magenta underline; the inactive one is 50% white.
  - **Key messages:** list of paragraphs, 15px, 72% white.
  - **Script:** rows with the timestamp (magenta, 36px column) and the line text.
- **Footer bar** (hairline top, padding 16px 56px): right-aligned primary button "Next: <next task title> →". On the last task it reads "Back to <Phase>".

## Interactions & behaviour
- **Phase row click:** selects the phase, expands it, collapses the others, and shows the phase intro. Clicking the already-open phase also returns to its intro.
- **Intro button:** opens the first task of the phase.
- **Task row click:** opens the task in the content pane and resets the tab to Key messages.
- **Next button:** goes to the next task in the phase; on the last task it returns to the phase intro.
- **App menu:** hover to expand, overlaying the page; leave to collapse.
- **Hover states:** filled elements darken; list rows take an 8% white wash. No scale or shadow effects.

## State
- `phaseIndex` (default 1 = Discover)
- `taskIndex` (null = phase intro; otherwise a flat index within the phase)
- `tab` ('km' | 'script')
- `navOpen` (bool)
- From data: phase status (closed / current / upcoming) and task done flags. The prototype hard-codes Prepare as closed (all tasks done) and Discover as current.

Data shape per phase: `{ name, mode, head, pay, lede, stat?, statLabel?, groups: [{ label: "Name · qualifier", tasks: [[title, desc, duration, kind('video'|'task'), notesKey?]] }] }`

## Design tokens
| Token | Value |
|---|---|
| Magenta (primary) | `#D946A0` · hover `#B83786` |
| Steel (secondary / timeline) | `#4394AF` |
| Page | `#000000` |
| Menu surface | `#0A0A0B` |
| Panel / selected | `#121214`, `#1C1C20`, `#2A2A30` |
| Text | `#FFFFFF`, 72% / 50% white |
| Hairline | `rgba(255,255,255,.16)`; wash `rgba(255,255,255,.08)` |
| Headings | Marcellus 400 (19 / 26 / 28 / 40px) |
| Body | Inter 400/600/700 (13 / 15 / 17px) |
| Captions | Gilda Display 400 (14px) |
| Eyebrow | 12–15px, uppercase, tracking .18–.22em, 600–700 |
| Radii | 4px controls, 8px panels, 12px media |
| Motion | 180ms `cubic-bezier(.2,0,.2,1)` |

## Assets
- `assets/samuh-s-mark.jpg`: the S mark for the collapsed menu (white on black; the prototype uses `mix-blend-mode:lighten` on a dark surface).
- `assets/samuh-wordmark-white.png`: the full wordmark for the expanded menu.
- Icons: placeholders; replace them with the product icon set.

## Files
- `Ritualizer Journey.html`: self-contained clickable prototype.
- `Ritualizer Journey.dc.html`: source (template + logic class). It needs the Samuh design-system bundle to run, so use the `.html` version for viewing.
