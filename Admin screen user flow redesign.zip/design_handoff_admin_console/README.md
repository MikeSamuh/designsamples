# Handoff: Admin Console — organization & team setup redesign

## Overview

A redesign of the Samuh admin experience: how a staff admin creates an organization,
builds its roster, connects MHQ surveys to each measurement point, monitors
participation, and reads the TeamQ/OrgQ reports.

It replaces the current tab-per-task admin area (`/admin/orgs`, `/admin/invitations`,
`/admin/journey-progress`) with **one scrolling console per scope**, reachable from a
persistent organization/team spine. Everything for a scope lives on its page, ordered
by the journey phases the member-side app already uses — not by CRUD entity.

**The console is deliberately sparse: two panels for an organization, one for a team,
plus the report.** An earlier, denser version is included in this bundle for reference
(`Admin Console Wireframe (detailed).dc.html`) — it is **superseded**. Build the simple one.

The two problems it solves, in the user's words: *"survey connect + revision selection
is confusing"* and *"too many tabs / hard to know where you are."*

## About the design files

The files in this bundle are **design references authored in HTML** — a working
prototype of the intended structure, copy and behavior. **They are not production code
to copy.** `Admin Console Wireframe.dc.html` is a single-file component in a bespoke
streaming-HTML runtime (`<x-dc>` template + a `Component` logic class); it will not
drop into Next.js.

The task is to **rebuild these screens in `apps/web`** using its existing conventions:
Next.js App Router pages under `src/app/admin/`, the primitives in `packages/ui/src/primitives/`
(`Button`, `Card`, `Field`, `Input`, `Select`, `RadioGroup`, `Table`, `Dialog`, `Badge`),
and the CSS custom properties in `apps/web/src/app/globals.css`. Every color and type
size in this prototype was lifted **from those tokens** — see *Design tokens* below for
the literal→token map. Use the token, not the hex.

Open the HTML in a browser to click through it. It has no build step and no network calls.

## Fidelity

**High-fidelity in structure, copy and behavior; token-accurate in styling.**

- Layout, hierarchy, information architecture, copy, empty states, badge wording and
  interaction flow are all final — implement them as specified.
- Colors, type sizes, radii and spacing are the real values from `globals.css`, but they
  are written as **literal hex and px** in the prototype because it has no access to the
  app's stylesheet. Swap each for its `var(--*)` token when implementing.
- Type is **Source Sans 3** in the prototype, standing in for the app's **Geist**. Use Geist.
- All data is fixtures. No API is wired up.

> Note on the design system: the Samuh Design System bound to this project is a
> **document and presentation** system (black ground, magenta/cyan accents, 1280×720
> slides). Its own guide states it ships **no product UI kit**. This is product UI, so it
> is grounded in the `apps/web` + `packages/ui` tokens and primitives instead. Do not
> restyle the admin console to the deck palette.

---

## Information architecture

Three scopes, one console each, all reachable without leaving the page:

```
Sidebar spine                  Console
─────────────────────────────  ────────────────────────────────────
All organizations         →    Portfolio: every org on its journey
  └ Meridian Health       →    Org console
      └ Clinical Ops      →    Team console
      └ Commercial
      └ Supply Chain
  └ Northwind Logistics
  └ Argent Bank
```

The spine is always visible and always reflects what you are looking at. Breadcrumb +
title restate it above the console. This is the answer to "hard to know where you are".

**Journey vocabulary is shared with the member app** (`lib/steps.js`, `lib/stepTasks.js`):

- **Org journey (5):** Prepare → Launch → Results → Action → Closing
- **Team journey (6):** Prepare → Discover → Empathize → Crystallize → Iterate → Close

The org console's sections are named for the org phases, so the admin and the member are
looking at the same process under the same names.

---

## Screens / views

### 1. All organizations (portfolio)

**Purpose.** Triage across clients: which org needs attention, and where each one is.

**Layout.** Sidebar (230px, sticky) + content column, 24px gap, 48px page padding.
Content: header block, then *Needs attention*, then one card listing every org.

Each org row: name + meta button (190px), a 5-phase journey rail (`flex: 1 1 420px`,
`min-width: min(420px, 100%)` so it wraps to its own line), status badge.

**Journey rail.** A 5-column grid (`repeat(5, minmax(96px, 1fr))`) inside an
`overflow-x: auto` wrapper, with `min-width: max-content` on the grid — copied from
`PathNavigator.module.css`. A 2px `--border` track sits at `top: 9px`, inset 10% each
side; a `--accent`-dark (#356499) fill covers `(100 - 100/5) × (phase / 4)` percent from
`left: 10%`. Dots are 18px circles, 2px border: filled #356499 when done, `--accent`
with a `0 0 0 4px rgba(74,158,255,.25)` ring when current, `--bg`/`--border` when future.
Current label is 600 weight in `--text`; done labels `--text-dim`; future `--text-faint`.

**Needs attention.** Only rendered when non-empty. Each row: a 6px status dot, the
problem stated as a consequence, and the fix as a button. Derived, never stored:

| Condition | Row copy | Action(s) |
| --- | --- | --- |
| `syncStatus === 'failed'` | "last MHQ sync failed, no new responses since {when}" | Retry sync · View error |
| no `credential` | "no MHQ credential, so no survey can be connected" | Link credential |
| credential, no stage connected | "no survey connected, so nothing can be measured" | Connect survey |
| `0 < responded < threshold` | "{team} has {n} respondents — {threshold} needed before its Discover results unlock" | Nudge {n} people |
| team has no manager | "{team} has no manager, so nobody can run its workshops" | Invite a manager |

On the portfolio each row is prefixed "{Org name} — ". On an org console it is unprefixed
and scoped to that org. Acting on a row removes it.

### 2. Org console — two panels

The console was deliberately cut from eight panels to two. What was removed and why:
a Results panel whose only durable number now lives in the page subhead; per-team
participation bars (the same information is one line inside each stage row); a threshold
paragraph (stated where it applies instead); a separate audience-list panel (folded into
the stage row it describes); a "Look ahead" line; and Hotspots. **Do not reintroduce them
without asking** — the brief was explicitly "fewer sections, and less inside each."

**Header.** Breadcrumb, org name, then one subhead carrying the state that matters:
`{Phase} · {pct}% participation · {responded} of {members} responded`. Actions: Run sync
(when a survey is connected) · Invite someone.

**Phase strip.** Not a panel — a bare 13px-dot strip directly under the header, same
geometry as `PathNavigator` (see *Journey rail* below), 5 phases for an org, 6 for a team.

**Needs attention** (conditional). Single-line rows: status dot, the problem as a
consequence, and actions as **quiet text links** right-aligned (primary in `--accent`,
secondary in `--text-faint`) — not buttons, so a row stays one line.

| Condition | Row copy | Action(s) |
| --- | --- | --- |
| `syncStatus === 'failed'` | "last MHQ sync failed, no new responses since {when}" | Retry sync · View error |
| no `credential` | "no MHQ credential, so no survey can be connected" | Link credential |
| credential, no stage connected | "no survey connected, so nothing can be measured" | Connect survey |
| `0 < responded < threshold` | "{team} has {n} respondents — {threshold} needed before its Discover results unlock" | Nudge {n} people |
| team has no manager | "{team} has no manager, so nobody can run its workshops" | Invite a manager |

On the portfolio each row is prefixed "{Org name} — ". Acting on a row removes it.

**Panel 1 — Measurement.** Title + a `{n} of 2 connected` badge. Then **one row per
measurement stage**, and this is the core of the redesign:

> Every team journey is measured at two points, and **each one is its own survey
> connection** — usually the same survey at two revisions, but they can be different
> surveys entirely.

| Stage | Title |
| --- | --- |
| `discover` | Discover · day 0 |
| `close` | Close · day 90 |

Each row is an `--inset` block, 8px radius, laid out: status dot · stage title (118px
fixed) · a two-line detail column · actions.

- Connected → line 1 `{survey name} · {revision label}` in `--text`; line 2
  `Everyone in {Org} | {n} of {m} teams · {responded} of {members} responded` in `--text-dim`.
  Actions: **Edit** (outlined, reopens the connect dialog pre-filled) · **Disconnect**
  (bare text link, `--text-faint`).
- Empty → line 1 "Not connected" in `--band-struggling`; line 2 the stage-specific
  consequence ("Teams have nothing to answer in their Discover workshop." /
  "Connect it before the first team reaches Close."). Action: **Connect survey** (primary).
- No credential → the panel body collapses to a single inset line plus Link credential.

**Panel 2 — People.** Title + a counts line
(`{n} teams · {n} members · {n} accepted[· {n} pending]`) + Import CSV · Invite someone.
Then teams as **chips** (name + member count; amber border when the team has no manager)
followed by a dashed **New team** chip. Then, only when non-empty, pending invitations as
bare rows above a hairline: email · `{Role} · {scope} · sent {when}` · Resend / Revoke as
text links.

### 3. Team console — one panel

Header and phase strip as above (6 team phases; the subhead reads
`{Phase} is the open phase · {n} members`).

**Roster.** Title + the team's survey state as its **subtitle** — *Connected directly*
(its own audience, its own revision answer), *Via the whole org*, *Not an audience*, or
*No survey* — then Import CSV · Invite, plus a **Connect this team** button that appears
only when there is something to connect. Revision choice is never duplicated here.

The table (`packages/ui` `Table`): Name · Email · Role · Status · TeamQ+ (right-aligned).
Rows are derived from the team's counts so the header total and the row count always
agree: `members` rows, the first `accepted` accepted, the first `responded` responded, plus
the Samuh coach (on the team, not a respondent, not counted in `members`). Rows added by
invitations this session carry the real submitted email and role, status "Invited just now".

**Journey rail geometry** (used by the strip and the portfolio rows) — a grid of
`repeat(N, minmax(92px, 1fr))` inside an `overflow-x: auto` wrapper with
`min-width: max-content` on the grid, per `PathNavigator.module.css`. A 2px `--border`
track sits at `top: 6px`, inset 10% (org) / 8.33% (team) each side; a #356499 fill covers
`(100 - 100/N) × (phase / (N-1))` percent from the same left inset. Dots are 13px circles
with a 2px border: filled #356499 when done, `--accent` with a
`0 0 0 4px rgba(74,158,255,.25)` ring when current, `--bg`/`--border` when future. Current
label 600 weight in `--text`; done `--text-dim`; future `--text-faint`.

### 4. Report (inline, both consoles)

Not a destination — it renders at the foot of the console it belongs to. This is
**exactly the member-side read**, recreated from `components/panels/AwarenessPanel.js`,
which members see on the **Awareness** step (*not* Discover — `stepTasks.js` gives Discover
only "pick a metaphor card" and "take the TeamQ+ survey").

- **Admin context strip** — scope, `n of m` responded (amber below threshold), measurement
  point + revision id. Context only; no actions.
- **Header row** — "{Scope} — TeamQ/OrgQ report", one line of context ("Exactly what the
  team reads on its Awareness step."), and **the four exports: Export client deck · Share
  read-only link · Download CSV · Download PDF.** These were the one thing the user marked
  as must-keep — they stay visible while reading, never behind a menu.
- **Hero** (`TeamQVisual`) — a 3-column grid, `1fr 1.1fr 1fr`: the wordmark and score /100
  (32px); "Capacity to perform" with the 6-band ladder (18px swatches, 24px rows) beside a
  22px figure; "Performance loss" as a percentage over days/hours.
- **Two bar charts** (`BarChart` + `lib/awarenessData.js`) — *Team environment* (10 rows,
  `--chart-pink`) and *Team practices* (13 rows, `--chart-teal`). Row geometry: 175px
  right-aligned 11px label, 18px track, bar width `value / 9 × 100%`, `min-width: 24px`,
  value printed inside the bar in white 600. **No voting stars** — those belong to members.
- Below threshold, or with no survey for the point → the same lock the members get, with
  the reason and the count needed.

### 5. Dialogs

All dialogs sit on a `rgba(0,0,0,.55)` backdrop, `96px 24px 24px` padding, and **close on
backdrop click** (guarded by `e.target === e.currentTarget` so clicks inside the panel do
not dismiss).

#### Connect a survey — 620px (the redesigned one)

Three numbered decisions on one screen. 22px numbered circles in the left gutter; a step
not yet reachable renders its number and label in `--text-faint`.

1. **Which survey?** — a search field (name, alias, or the name of any org already using
   it) with a live "3 of 5" count, over a flat result list (no group headings; 246px
   max-height, scrolls). Each row: name, badge ("On Discover" / the other org's name /
   "Draft"), and `alias · n revisions · ends {date}`, with a chevron. Picking one
   **collapses the whole search into a chosen-survey row** with a Change link, so the
   directory stops competing for attention. Empty state offers "Show all surveys".
2. **Which revision?** — radio rows of that survey's revisions: label, `id · published
   {date}`, and a tag ("Newest" on the first, "On Discover/Close" when already in use).
   **The newest is pre-selected on pick**, so one click is usually enough. Before a survey
   is chosen the step stays in place, greyed, reading "Pick a survey and its revisions
   appear here" — the layout never jumps.
3. **Who answers it?** — "Everyone in {Org}" as a single checkbox row noting "{n} people
   across {m} teams — new teams are included automatically", then a hairline rule labelled
   "Or single teams" and the teams as toggle chips with member counts.

**Footer** reads the result back in plain English — *"Everyone in Meridian Health will
answer Meridian TeamQ — 2026 sprint at TeamQ+ v5 — Jun 2026 in Discover."* — and the
primary button stays inert (`--chip` bg, `--text-faint`, `not-allowed`) until that
sentence is true. Before then the footer states what is missing.

Deliberately **not** in this dialog: group headings, an explainer paragraph, and the
End date / Unrealized revenue fields — the survey carries its own end date from MHQ, and
revenue is not part of connecting.

#### Invite someone — 544px

Email; Role as radio rows (Team Member / Manager / Samuh Coach / **Samuh Admin**); scope
derived from role (Team Member and Samuh Admin lock it); Organization and Team selects;
a live readout.

**Samuh Admin is drawn but refuses to send.** It is rendered dashed and disabled with the
reason stated: *samuh_admin* outranks every role, so `allowedInviteRoles` never offers it
— shipping it needs a backend policy change. Surfacing the gap is intentional; do not
"fix" it by enabling the option.

#### Add an audience — 544px

Radio list of the whole org and any team not yet receiving the stage's survey. Note:
"An audience gets its own revision answer — that is why 'revision 1 to Clinical Ops,
revision 2 to Supply Chain' is expressible at all."

#### New organization / New team — 440px · Sync error — 640px

Name field; the org dialog states the credential is linked automatically. The sync error
shows the raw `MhqAuthError` log in a monospace `--inset` block with Copy report.

---

## Interactions & behavior

- **Navigation.** Spine and breadcrumbs both navigate. Selecting an org expands its teams
  beneath it. Highlighting keys off *what the view is about*, not the route name.
- **Create org** → lands on its console genuinely empty; *Needs attention* then carries the
  setup work as its own items.
- **Invite** → appends a real pending invitation, increments the team's member count,
  clears that team's "no manager" flag when the role is Manager, and adds a roster row.
- **Connect** → writes into `stages[stage]`, sets `syncStatus: 'succeeded'`, and advances
  `phase` to at least Launch.
- **Toasts** — bottom-center, 4.2s auto-dismiss plus a Dismiss button, with a tone dot
  (`--band-thriving` success / `--accent` info / `--band-distressed` destructive).
- **Threshold** — below `respondentThreshold` (default 5) a team is not reported on. Stated
  up front everywhere it applies rather than discovered when a report comes back empty.
- **Hover** — rows lighten to `--inset`; buttons follow `packages/ui` `Button`.
- **Responsive** — the console reflows (`flex-wrap`, `minmax(0, 1fr)` tracks); journey rails
  scroll horizontally rather than overflow.

## State

Single component state in the prototype; in the app this is server data plus local UI state.

**Server (per org):** `id`, `name`, `phase`, `credential`, `stages: { discover, close }`
(each `{ name, alias, ends, audiences: string[], revision: { id, label } }` or `null`),
`syncStatus`, `syncAt`, `teams[]` (`id`, `name`, `members`, `accepted`, `responded`,
`manager`, `phase`, `tasksDone[]`), `pending[]`.

**UI:** `route` (`orgs` | `org` | `team`), `orgId`, `teamId`, `dialog`, `point`
(`discover` | `close` — the selected measurement point), and per-dialog drafts
(`connectStage`, `connectQuery`, `connectAlias`, `connectRevision`, `connectPicked`,
`inviteRole`, `inviteScope`, `audienceStage`, `draftAudience`).

**Audiences are a single source of truth.** `stages[stage].audiences` is an array of
`'org'` and team ids. Every summary — the Launch grid cell, the audience list, the team
console's badge — is derived from it, so they cannot contradict each other. `'org'` is
removable: "only these two teams answer" is a legitimate setup, and removing it is what
makes the team console's *Not an audience* state reachable.

**One search predicate.** The connect dialog's list, its result counter and its empty state
all read the same `connectMatch` function. (They were separate once; the counter said
"0 of 5" above a visible row.)

## API surface needed

- `GET` MHQ survey directory for a credential → `{ alias, name, status, ends, revisions: [{ id, label, publishedAt }] }`
  (`useMhqSurveyDirectory` already exists — extend it to return revisions per survey).
- `POST` connect: `{ orgId, stage, alias, revisionId, audiences[] }`
- `DELETE` connect: `{ orgId, stage }`
- `PATCH` audiences: `{ orgId, stage, audiences[] }`
- `POST` sync / retry sync → `{ status, at, error? }`
- Invitations: create / resend / revoke
- Report payloads per scope + measurement point, with a `reportable` flag and the
  respondent count so the client never has to infer the lock.

## Design tokens

Literal values in the prototype → the token to use. All from `apps/web/src/app/globals.css`.

| Prototype | Token | Role |
| --- | --- | --- |
| `#1c1d1f` | `--bg` | page ground |
| `#232426` | `--card` | panels, dialogs |
| `#0e0f10` | `--inset` | inset rows, inputs, tracks |
| `#333438` | `--border` | 1px hairlines |
| `#4a9eff` | `--accent` | selection, links, current phase |
| `#2f7fe0` | `--accent-button` | primary button fill |
| `#e8e9eb` | `--text` | body ink |
| `#8a8d93` | `--text-dim` | secondary ink |
| `#55585e` | `--text-faint` | tertiary / disabled ink |
| `#2b2c2e` | `--chip` | badges, secondary buttons |
| `#356499` | — | completed journey fill (derived from `--accent`) |
| `#3ba55d` `#2b8bd4` `#4db8e8` `#b0b0b0` `#e88a2a` `#e0402a` | `--band-thriving` … `--band-distressed` | the six bands |
| `#d6409a` / `#3a95ac` | `--chart-pink` / `--chart-teal` | environment / practices bars |
| `#eb0b83` | — | 4px note rule (the one Samuh-brand magenta used) |

**Type** (`--fs-*`): 11px eyebrow (uppercase, `.05em`), 12px sub, 13px body, 17px title,
22px heading, 32px display. Weights 400/500/600 only.

**Spacing** — 8px base. Page 48px; panel 14px 16px; dialog 20-22px 24px; gaps 2/4/6/8/10/12/14/16/20/24.

**Radius** — 4px controls, 8px rows/inputs/buttons, 10px panels and dialogs, 999px dots.
Chart bars and journey tracks are square (2px on the track only).

**Shadow** — `0 3px 14px rgb(0 0 0 / .5)` raised panel, `0 8px 30px rgb(0 0 0 / .5)` dialog.

## Assets

- `assets/samuh-logo.png` — the wordmark in the console header (28px tall). Included.
- All icons are inline 24×24 `stroke="currentColor"` `stroke-width="1.75"` SVG paths
  (Lucide geometry, matching the app's existing `lucide-react` usage). Replace with
  `lucide-react` imports: `Building2`, `UsersRound`, `MailPlus`, `Plus`, `Check`, `Minus`,
  `Link2`, `Lock`, `Search`, `ChevronRight`, `ChevronDown`, `Download`, `TriangleAlert`, `Play`.
- No raster imagery, no photography.

## Files in this bundle

| File | What it is |
| --- | --- |
| `Admin Console Wireframe.dc.html` | **The design — build this.** Open in a browser; fully clickable. |
| `Admin Console Wireframe (detailed).dc.html` | Superseded denser version, kept for reference only. |
| `Connect Survey A.dc.html` | Explored option: search-and-expand, revisions inline. |
| `Connect Survey B.dc.html` | Explored option: three-step wizard. |
| `Connect Survey C.dc.html` | Explored option: fill-in-the-sentence. |
| `assets/samuh-logo.png` | Wordmark used in the header. |
| `support.js` | Runtime the `.dc.html` files need to render. Do not port it. |
| `_ds/…/tokens/fonts.css` + `assets/fonts/` | Source Sans 3 (400/600/700 latin), so the bundle renders offline. |

Open `Admin Console Wireframe.dc.html` directly from the unzipped folder — keep the
folder structure intact so `support.js`, the logo and the fonts resolve. No server needed.

The three `Connect Survey` files are **superseded explorations**, kept for rationale. The
shipped design is the dialog inside `Admin Console Wireframe.dc.html`, which took A's
one-screen shape and rebuilt it around the three numbered decisions.

## Source files this was built from

Read these before implementing — the prototype's values were lifted from them:

| Concern | Source |
| --- | --- |
| Tokens | `apps/web/src/app/globals.css` |
| Primitives | `packages/ui/src/primitives/{button,card,field,input,select,radio-group,table,dialog,badge}.tsx` |
| Journey rail | `apps/web/src/components/**/PathNavigator.module.css` |
| Journey phases & tasks | `apps/web/src/lib/steps.js`, `apps/web/src/lib/stepTasks.js` |
| Member report | `apps/web/src/components/panels/AwarenessPanel.js`, `components/prepare/TeamQVisual.{js,module.css}`, `components/awareness/BarChart.{js,module.css}`, `lib/awarenessData.js` |
| OrgQ panels | `apps/web/src/components/panels/orgq/OrgResultsPanel.js`, `components/orgq/{HotspotTeams,RiskHeatMap}.js` |
| Setup progress glyphs | `packages/*/setup-progress.tsx` |
| Current admin screens being replaced | `apps/web/src/app/admin/{orgs/page.jsx,orgs/org-content.jsx,invitations/page.jsx,journey-progress/page.jsx}` |

## Open questions for the team

1. **Samuh Admin invites** — the role is designed but blocked by `allowedInviteRoles`.
   Needs a policy decision before it can ship.
2. **Close revision default** — if nobody picks one by day 90, should it auto-select the
   newest published revision, or block the Close workshop?
3. **Unrealized revenue** — cut from the connect dialog. Where does it actually belong?
5. **What was cut** — per-team participation bars, Hotspots, and the org Results panel
   were removed for simplicity. If any of them turn out to be load-bearing for a real
   task, they should come back as a disclosure rather than a permanent panel.
4. **Report numbers** are the app's own illustrative figures; `awarenessData.js` is static
   in the codebase too. Wire to real assessment data.
