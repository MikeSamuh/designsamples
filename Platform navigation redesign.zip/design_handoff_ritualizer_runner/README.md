# Handoff: Ritualizer — Phase Overview & Guided Task Runner

## Overview

A redesign of the Ritualizer platform's core loop: how a user moves from a phase overview
into an individual task, and from one task to the next. The existing product drops the user
into a hollow full-screen view with a thin bottom bar ("Discover — 2 of 11", a `Next ⌄`
chevron, an `×`) that provides no orientation, no sense of progress, and no clear next action.

This redesign replaces that with a **guided run**: the phase overview is a map you enter once,
and the full-screen runner carries the user through every task in the phase with persistent
orientation (which phase, which task, how much is left, what comes next).

**Two phases are built** — Discover (11 tasks) and Empathize (7) — specifically so the port
has proof the model is phase-agnostic: nothing in the runner, the status box, the gate or the
phase-close screen is hardcoded to Discover. The remaining four phases are declared with empty
task arrays and render as dim, unclickable entries in the phase strip.

**Important: the task content in this bundle is placeholder.** The tasks, their copy,
durations and roster were reconstructed from screenshots of the current product because the
`samuh-dashboard` codebase was not readable from the design environment. Treat the *structure*
(task kinds, state machine, gating, navigation) as the deliverable and wire the real task
content from the codebase's own data source. See **Content is placeholder** below.

## About the Design Files

The files in `design/` are **design references created in HTML** — a prototype showing the
intended look and behaviour. They are **not production code to copy directly**.

`design/Ritualizer Redesign.dc.html` is a single-file prototype built on a bespoke streaming
component runtime (`<x-dc>`, `<sc-for>`, `<sc-if>`, `{{ }}` template holes, a `Component
extends DCLogic` logic class, inline styles only). That runtime does not exist outside the
design tool and **must not be ported**. Read the file as a specification:

- the `class Component extends DCLogic` block is the state machine — port its logic
- `renderVals()` returns the view model — port its derivations
- the template markup is the layout and styling spec — recreate it in the app's own components
- `<sc-for list>` is a `.map()`, `<sc-if value>` is a conditional render

The task is to **recreate these designs inside `samuh-dashboard`'s existing environment**,
using its established component patterns, routing, styling approach and state library. Do not
introduce a new styling system to accommodate this handoff. If the runner does not yet have a
home in the app, add it as a route (e.g. `/journey/:phase/run/:taskIndex`) so a task is
addressable, shareable and browser-back works — the prototype fakes this with local state.

## Build on the design system's components, not raw HTML

The prototype mounts the bound Samuh Design System's own React components from
`_ds/.../_ds_bundle.js`. Recreate with the same components (or `samuh-dashboard`'s
equivalents), not hand-styled HTML:

| On screen | Component | Notable props used |
| --- | --- | --- |
| Wordmark in the overview header | `Wordmark` | `tone="white"`, `width={176}` — resolves `assets/logo/samuh-wordmark-white.png` relative to `assetBase` |
| Every tracked uppercase label (~12) | `Eyebrow` | `tone="magenta" \| "muted"`, `size="sm"` |
| "Facilitator mode" / "Solo mode" chip | `Badge` | `tone="magenta"`, `variant="outline"` |
| Every button and the coaching link | `Button` | `variant="primary" \| "secondary" \| "quiet"`, `size`, `arrow`, `href`, `disabled` |
| All stat pairs (27%, 87, 7/9, 62, 13, phase-close band) | `StatBlock` | `value`, `label`, `tone="cyan"`, `size`, `align="left"`, `divider` |
| "The workshop" box, facilitator script box | `Callout` | `label`, `tone="magenta"`; workshop box overrides `background:transparent` |
| Result bars | `CompareBar` | `label`, `start={0}`, `growth={score}`, `max={100}`, `delta`, `labelWidth`, `height` |

Two notes on those choices. `Button`'s `disabled` skin is a 0.4 opacity wash over magenta;
the runner overrides it to `rgba(255,255,255,.08)` on `rgba(255,255,255,.32)` ink, because a
dimmed-magenta button reading "Held until 9 of 9 have submitted" still reads as pressable.
And `CompareBar` is used with `start={0}`: at day 0 there is no day-90 growth to compare
against, so the cyan segment carries the whole measured score and `CompareBarLegend` is
omitted. Add the legend and split `start`/`growth` when the same screen is reused at day 90.

Components deliberately NOT used: `SlideFrame`, `SlideTitle`, `ArtefactCard`, `StepFlow`,
`IconTile`, `Quote` (deck furniture, no place in the runner) and the `forms/*` controls,
which the design system itself flags as unevidenced proposals.

## Fidelity

**High-fidelity.** Final colours, typography, spacing, motion and interaction states. Every
value below is exact and taken from the bound Samuh Design System token files, which are
copied into `design/tokens/` for reference. Recreate pixel-perfectly using the codebase's
existing primitives where they exist; use the token values where they do not.

Two flagged substitutions:

1. **Icons.** This is the only hand-drawn element left in the page. The Samuh Design System ships nine monoline PNG glyphs intended as *document*
   furniture (inside an `IconTile` on a slide) and explicitly forbids substituting an icon
   library in Samuh documents. It has no product-UI icon set. The prototype therefore uses
   hand-written 1.5px-stroke outline SVG paths for the left rail, close, back, next, play and
   check marks — the weight the design system names as the closest match for app chrome.
   **Replace these with `samuh-dashboard`'s existing icon set if it has one.** If it does not,
   commission or select a single 1.5px outline set and use it consistently.
2. **Wordmark size.** Rendered through the `Wordmark` component, but at an explicit
   `width={176}` rather than a named size. The component's presets are sm 96 / md 140 /
   lg 200 / xl 280, and it encodes no minimum — the asset is a 515×191 fine-line outline mark
   whose strokes go sub-pixel under about 170px, so `sm` and `md` both render it as a smudge.
   176 is the smallest width at which it reads. It appears **only** in the overview header,
   and is deliberately omitted from the runner header and the 64px rail. Request an SVG.

## Content is placeholder

| What | Status |
| --- | --- |
| Task titles, bodies, `who`, `mins` | **Placeholder** — reconstructed from screenshots |
| The eleven-task sequence for Discover | **Plausible but unverified** |
| The nine-person roster names | **Placeholder** — role titles, not real people |
| Metaphor cards, keystone practice options, vote tallies | **Invented** |
| TeamQ result bars and scores | **Invented** |
| Phase names and day markers (Prepare … Close) | **From the screenshots — likely correct** |
| Task *kinds* and their behaviours | **This is the design** — port as-is |
| Navigation, gating, progress model | **This is the design** — port as-is |

Wire titles, bodies, durations, assignee scope, roster and results from the real API. The
seven task kinds are the contract the UI needs; everything else is data.

## Voice of the copy

All copy in the prototype follows the Samuh Design System's content rules, and replacement
copy must too:

- Third person and evidential. Samuh writes about itself by name, never "we".
- Sentence case everywhere except tracked uppercase eyebrows.
- Statement, then correction — the second fragment is the point and takes the magenta:
  *"The team measured itself and agreed what it is for. **Nothing has changed yet.**"*
- Numbers always paired with what they measure: "9 of 9 have submitted", "97 min of tasks".
- Hyphen, not em dash, for parentheticals. Curly quotes for named rituals.
- **No emoji, ever.** The only non-alphabetic glyphs permitted are `→` and `|`.
- No superlatives, no exclamation marks, no growth-marketing verbs.

---

## Screens / Views

### 1. Phase Overview

**Purpose.** Orient, then enter. This is a map, not a workspace — the user reads where the
team is and presses one button. It replaces the old screen where eleven equal-weight tiles
competed with a permanently-lit task checklist.

**Layout.** Root is `display:flex; min-height:100vh; background:#000`.

- **Left rail** — `width:64px; flex:0 0 64px; border-right:1px solid rgba(255,255,255,.16)`,
  `display:flex; flex-direction:column; align-items:center; padding:18px 0 14px; gap:2px`.
  Opens with a `40×1px` hairline at `rgba(255,255,255,.16)`, `margin-bottom:18px` (this is
  where the wordmark deliberately is *not*). Then six 40×40 icon buttons, `border-radius:4px`,
  transparent background, `19×19` SVG at `stroke-width:1.5`. Active item: stroke `#EB0B83`,
  background `rgba(235,11,131,.16)`. Inactive: stroke `rgba(255,255,255,.5)`, transparent.
  Hover: `background:rgba(255,255,255,.08)`, `transition:background 120ms cubic-bezier(.2,0,.2,1)`.
  A `flex:1` spacer, then `v.83` at `11px / rgba(255,255,255,.32) / letter-spacing:.06em`.
  Rail items in order: Journey (active), Team, Diagnostics, Library, Notifications, Settings.
- **Main** — `flex:1; min-width:0; display:flex; flex-direction:column`.

**Header.** `display:flex; align-items:flex-start; justify-content:space-between; gap:32px;
padding:34px 48px 26px; flex-wrap:wrap`.

Left block, in order:
- Wordmark `<img>` — `width:104px; height:auto; display:block; margin-bottom:18px`
- Eyebrow "Ritualizer" — `13px / 600 / letter-spacing:.22em / uppercase / #EB0B83`
- `<h1>` "Team Journey" — `34px / 600 / letter-spacing:-.01em / line-height:1.15`,
  `margin:8px 0 5px`
- Sub "for Customer Success" — `17px / rgba(255,255,255,.5)`

**No absolute day counts anywhere in the chrome.** Sprints are not always 90 days, so position
is expressed structurally instead: "phase 2 of 6" in the status box, "closed" / "in the room
now" in the phase strip, "TeamQ score at the start" on the close screen. Do not reintroduce
"day N of 90" — if a sprint length exists in the data it belongs in content, not in chrome.

Right block, `display:flex; align-items:center; gap:10px; flex-wrap:wrap`:
- Mode badge — text `Facilitator mode` or `Solo mode`, `12px / 600 / letter-spacing:.18em /
  uppercase / #EB0B83`, `border:1px solid rgba(235,11,131,.28)`,
  `background:rgba(235,11,131,.16)`, `border-radius:4px`, `padding:8px 12px`
- User chip — `border:1px solid rgba(255,255,255,.16)`, `border-radius:4px`,
  `padding:6px 14px 6px 8px`, `gap:10px`; avatar `28×28`, `border-radius:50%`,
  `background:#1C1C20`, initials `12px / 600 / rgba(255,255,255,.72)`; name
  `15px / rgba(255,255,255,.72)`

**Phase strip.** `padding:0 48px; border-bottom:1px solid rgba(255,255,255,.16)`, containing
`display:flex; gap:3px`. Six equal `flex:1; min-width:0; padding-bottom:16px` cells, each:
- a `3px` bar, `margin-bottom:11px` — square ends, **no radius** (chart-bar rule):
  done and current phases `#EB0B83`, future `rgba(255,255,255,.16)`
- name — `15px / 600`, `#fff` for done/current, `rgba(255,255,255,.5)` for future,
  `white-space:nowrap; overflow:hidden; text-overflow:ellipsis`
- note — `13px / rgba(255,255,255,.32)`, same truncation
- Content: Prepare "closed day 0" · Discover "in the room now" · Empathize "day 14" ·
  Crystallize "day 30" · Iterate "day 60" · Close "day 90"

**Body.** `display:grid; grid-template-columns:minmax(0,1.6fr) minmax(240px,1fr); gap:48px;
padding:40px 48px 80px; align-items:start`.

*Left column:*

1. **Workshop callout** — `border-left:4px solid #EB0B83; padding:2px 0 2px 20px;
   margin-bottom:32px`. Eyebrow "The workshop" (`13px / 600 / .22em / uppercase / #EB0B83`,
   `margin-bottom:10px`); body `22px / line-height:1.42 / text-wrap:pretty / max-width:54ch`;
   meta line `15px / rgba(255,255,255,.5)`, `margin-top:14px`.
   Copy comes from the phase's own `intro`; the meta line is `introMeta` plus a **computed**
   `{sum of task mins} min of tasks` — never a hardcoded total (the original hand-written "97
   min" had already drifted from the real 102).
2. **Resume card** — `background:#121214; border:1px solid rgba(255,255,255,.16);
   border-radius:8px; padding:22px 24px; display:flex; align-items:center; gap:24px;
   flex-wrap:wrap; margin-bottom:38px`.

   **The card describes the specific task you are about to resume**, not the run in the
   abstract — four stacked lines plus a verb-matched button:
   - eyebrow — "Picks up at task 4 of 11" (or "Starts with task 1 of 11" when nothing is done,
     "Waiting on the session" when held)
   - headline — the task's own title, `22px / 600 / -.01em / text-wrap:pretty`
   - sub — `15px / rgba(255,255,255,.5)`: `"{who} · {mins} min · {n} of {total} tasks left"`
   - note — `15px / rgba(255,255,255,.32)`, per task kind: what the task will ask of you
     ("Everyone votes on their own screen. The room sees the count, not who voted."). The
     `gate` kind substitutes live state instead: "7 of 9 have taken TeamQ+. The facilitator
     releases the room."
   - button — the verb for that kind, never a generic "Resume": **Play it** (video), **Open the
     reading** (read), **Open the diagnostic** (gate), **Write it together** (write), **Open the
     vote** (vote), **Read it together** (results), **Run the lap** (round). All done →
     "Review the run".

   The per-kind verbs and notes live in one `RESUME` map keyed by task kind — add a kind, add
   a row. ("Resume the run" was invented copy for this prototype and is now gone; rename these
   verbs freely, they are not product strings.)
3. **The run ladder** — section label `13px / 600 / .22em / uppercase /
   rgba(255,255,255,.5)`: "The run · {doneCount} of 11 done". Then an `<ol>` with no bullets;
   each row is a full-width `<button>`: `display:flex; align-items:flex-start; gap:16px;
   padding:15px 10px; border:0; border-bottom:1px solid rgba(255,255,255,.08);
   background:transparent`, hover `background:rgba(255,255,255,.08)`.
   - marker — `26×26`, `border-radius:50%`, `13px / 600`, `margin-top:2px`.
     Done: background `#EB0B83`, border `#EB0B83`, glyph `✓` in `#fff`.
     Next up: background `rgba(235,11,131,.16)`, border `#EB0B83`, number in `#EB0B83`.
     Ahead: transparent background, border `rgba(255,255,255,.16)`, number in
     `rgba(255,255,255,.32)`.
   - title — `18px / 600`; `#fff` when current, `rgba(255,255,255,.5)` when done,
     `rgba(255,255,255,.72)` when ahead; `text-wrap:pretty`
   - meta — `14px / rgba(255,255,255,.32)`, `margin-top:2px`: `"{who} · {mins} min"`
   - state chip, right-aligned — `12px / 600 / letter-spacing:.16em / uppercase`,
     `margin-top:6px`: "Done" (`rgba(255,255,255,.32)`), "Next up" (`#EB0B83`),
     "Ahead" (`rgba(255,255,255,.32)`), "Held" (`rgba(255,255,255,.32)`, title dimmed to
     32% and `cursor:not-allowed` — see *Session open/close*)

*Right column (`display:flex; flex-direction:column; gap:24px; min-width:0`):*

1. **The phase status box** — `border:1px solid rgba(255,255,255,.16); border-radius:8px;
   padding:22px`. **Scoped to the phase being viewed, and fully generic** — every value is
   derived, nothing says "Discover" in markup.
   - head row — a **muted** `Eyebrow` carrying the phase name (not magenta: magenta is reserved
     for the progress bar in the strip, which is marking progress rather than labelling), then
     "phase 2 of 6" at `14px / rgba(255,255,255,.32)`
   - big stat `44px / 600 / -.02em / #2CC8E8` + "of this phase done" — the label does not
     repeat the phase name, because the eyebrow just said it
   - progress bar `height:4px` on `rgba(255,255,255,.08)`, fill `#2CC8E8`,
     `transition:width 560ms cubic-bezier(.2,0,.2,1)`, `margin:18px 0 22px`
   - stat pair — a `1fr 1fr` **grid with `gap:24px`** above a
     `border-top:1px solid rgba(255,255,255,.16); padding-top:20px`. A flex row was tried first
     and the `StatBlock` divider collided with the label; the grid gap is what gives the
     divider its lane. Left is always `{minsLeft}` / "min of tasks left"; right is **the
     phase's own gate stat** — `7/9` "have taken TeamQ+" in Discover, `0/9` "have sat their
     1:1" in Empathize.

   The contract, for reuse on other phases:
   ```
   StatusBox { phaseName, phaseIndex, phaseCount, pctDone, minsLeft,
               gateStat: { value, label } | null }
   ```
   With `gateStat: null` the row should collapse to a single stat rather than render a
   lopsided grid — Prepare probably has no gate.
2. **"Book a coaching call"** — same container. Title `18px / 600`; body
   `15px / rgba(255,255,255,.5) / text-wrap:pretty`: *"Half an hour with Samuh about anything
   this phase raised."*; link "Schedule a conversation →" at `16px / 600 / #2CC8E8`, hover
   `#5FD8F0`. The arrow nudges 3px right on hover (design-system CTA rule).

---

### 2. Full-screen Task Runner

**Purpose.** Do one task, know exactly where you are, and be carried to the next. This is the
screen the redesign exists for.

**Layout.** `display:flex; flex-direction:column; min-height:100vh`, inside the same shell —
**the left rail stays visible.** The old design blanked the whole window, which is why users
lost their place; the runner is a mode, not a void.

**Sticky header** — `position:sticky; top:0; background:#000; z-index:5;
border-bottom:1px solid rgba(255,255,255,.16)`.

Row one: `display:flex; align-items:center; gap:20px; padding:18px 40px 14px; flex-wrap:wrap`.
- Left group `display:flex; align-items:center; gap:14px; flex:1; min-width:0;
  flex-wrap:nowrap` — **no wordmark here** (see substitutions):
  - "Discover" — `13px / 600 / letter-spacing:.22em / uppercase / #EB0B83; flex:0 0 auto`
  - meta — `14px / rgba(255,255,255,.5) / letter-spacing:.04em; white-space:nowrap;
    overflow:hidden; text-overflow:ellipsis`: `"Task {n} of 11 · {minsLeft} min left"`
- "All tasks" button — `border:1px solid rgba(255,255,255,.16); border-radius:4px;
  background:transparent; color:rgba(255,255,255,.72); font-size:14px; font-weight:600;
  padding:9px 14px`. Hover: border → `rgba(255,255,255,.32)`, background
  `rgba(255,255,255,.08)`, colour `#fff`.
- Close `×` — `36×36`, same outline treatment, `15×15` SVG at `stroke-width:1.5`,
  stroke `rgba(255,255,255,.72)`. Title attribute "Back to the phase". Returns to overview.

Row two — **the progress rail**, the core orientation device:
`display:flex; gap:3px; padding:0 40px 14px`. Eleven equal `flex:1; min-width:0` buttons,
each `height:20px` (generous hit area) containing a `width:100%; height:5px` bar,
`transition:background 180ms cubic-bezier(.2,0,.2,1)`, square ends, no radius:
- done → `#EB0B83`, centring a `9×9` black check SVG at `stroke-width:4`
- current → `rgba(235,11,131,.28)`
- upcoming → `rgba(255,255,255,.08)`

Every segment is clickable and jumps to that task; `title` is `"{n}. {title}"`.

**Content column.** `flex:1; display:flex; justify-content:center; padding:0 40px 140px`
(the 140px bottom padding clears the fixed action bar); inner `width:100%; max-width:760px;
padding-top:64px`, animated `ritIn 320ms cubic-bezier(.2,0,.2,1)` — keyed on task index so
each task slides in.

Header of every task, regardless of kind:
- kicker — `12px / 600 / letter-spacing:.22em / uppercase / rgba(255,255,255,.5)`,
  `margin-bottom:16px`; composed as `"{Kind} · {who} · {mins} min"`, e.g.
  "VIDEO · PLAYED TO THE ROOM · 5 MIN"
- title — `<h2>` `40px / 600 / letter-spacing:-.01em / line-height:1.12 / text-wrap:pretty`,
  `margin:0 0 16px`
- body — `19px / rgba(255,255,255,.72) / max-width:56ch / text-wrap:pretty`,
  `margin:0 0 40px`

**Fixed action bar** — `position:fixed; left:64px; right:0; bottom:0; background:#000;
border-top:1px solid rgba(255,255,255,.16); z-index:6`. Note `left:64px` — it starts after the
rail. Inner `display:flex; align-items:center; gap:18px; padding:16px 40px; flex-wrap:wrap`:

- **Back** — outline button, `padding:11px 16px`, `15px / 600`, with a leading `15×15`
  chevron. **Labelled with the previous task**, not "Back": `"3. Check in"`. On the first task
  it reads "Discover" and returns to the overview. This is a deliberate fix — the old bar's
  bare chevron told the user nothing.
- **Centre note** — `flex:1; min-width:0; text-align:center`,
  `15px / rgba(255,255,255,.5) / white-space:nowrap / overflow:hidden /
  text-overflow:ellipsis`. Normally `"Then: {n}. {next title}"`, or "Last task in Discover".
  During the completion beat it explains the pacing rule instead.
- **Primary** — `border:0; border-radius:4px; padding:14px 22px; font-size:16px;
  font-weight:600; gap:12px`, with a trailing `16×16` arrow SVG.
  Enabled: `background:#EB0B83; color:#fff`, hover `#C40A6E`.
  Blocked: `background:rgba(255,255,255,.08); color:rgba(255,255,255,.32);
  cursor:not-allowed`, no hover change.
  **The label always names the action or the reason it can't happen** — never a bare "Next".
  The arrow SVG is always present, so label strings must not include their own `→`.

---

### 3. Task-kind variants

Seven kinds. Each renders in the same content column, below the shared header.

**`video`** — 16:9 box, `border:1px solid rgba(255,255,255,.16); border-radius:8px;
background:#0A0A0B`, centring a `76×76` circular play button
(`border:1px solid #EB0B83; background:rgba(235,11,131,.16)`, hover
`rgba(235,11,131,.28)`) with a `24×24` `#EB0B83` triangle, plus a media note at
`15px / rgba(255,255,255,.5)`. Caption below at `15px / rgba(255,255,255,.32)`: *"Marks itself
done when the video ends, then opens the next task."* Primary: "Mark watched". **Passive —
auto-advances.**

**`read`** — a dark container, matching every other surface in the runner:
`background:#121214; border:1px solid rgba(255,255,255,.16); border-radius:8px;
padding:26px 28px`. Heading `24px / 600 / -.01em / #fff`; lead paragraph
`18px / line-height:1.55 / rgba(255,255,255,.72) / max-width:62ch`; tail paragraph
`16px / rgba(255,255,255,.5)`. Caption below: *"Scrolling to the end marks it done."*
Primary: "Mark read". **Passive — auto-advances.**

⚠️ **Do not use the white `ArtefactCard` here.** An earlier revision did, and it was rejected:
that white 12px card with the magenta cap is specified for *hand-drawn workshop artefacts
inside documents*, and inside the app it reads as a foreign object punched into the black.
Reading content is per-task (`readTitle` / `readLead` / `readTail`) — it must not be
hardcoded in the component, or every phase's reading task shows Discover's copy.

**`gate`** — the facilitator release gate. Container `border:1px solid rgba(255,255,255,.16);
border-radius:8px; background:#121214; overflow:hidden`.
- Head row `padding:22px 24px; border-bottom:1px solid rgba(255,255,255,.16)`:
  `"{submitted} of 9"` at `32px / 600 / #2CC8E8 / line-height:1`, then *"have submitted —
  results unlock at nine"* at `16px / rgba(255,255,255,.5)`
- A `4px` progress bar, fill `#2CC8E8`, `transition:width 560ms cubic-bezier(.2,0,.2,1)`
- Roster `<ul>`, `padding:8px 24px 18px`; nine rows `padding:11px 0;
  border-bottom:1px solid rgba(255,255,255,.08); gap:12px`. Each: a `22×22` circle —
  submitted `border:1px solid #2CC8E8; background:#2CC8E8` with an `11×11` black check at
  `stroke-width:4`; not yet `border:1px solid rgba(255,255,255,.16)`, transparent. Name
  `16px`, `rgba(255,255,255,.72)` when submitted, `#fff` when outstanding (the outstanding
  person is the one you need to look at). Note `14px / rgba(255,255,255,.32)`:
  "submitted" / "not yet"; the current user's row reads "you".
- Below: outline button "Nudge the two outstanding" and the note *"The facilitator releases
  the room — nobody is dropped into results early."*

Primary is **blocked until all nine have submitted, for both roles**. Facilitator: "Held until
9 of 9 have submitted" → "Release the room". Solo: "Waiting on the room" → "Open the results".

**`write`** — label `12px / 600 / .22em / uppercase / rgba(255,255,255,.5)`, then a
`<textarea rows="4">`: `background:#0A0A0B; color:#fff;
border:1px solid rgba(255,255,255,.16); border-radius:4px; padding:16px 18px; font-size:19px;
line-height:1.5; resize:vertical; width:100%`. Focus: `border-color:#2CC8E8` plus the
`0 0 0 3px rgba(44,200,232,.16)` ring — the only glow the system allows. Below, a hint at
`15px / rgba(255,255,255,.32)` and a "Saved" confirmation at `15px / #2CC8E8`.
Primary blocked below 9 trimmed characters: "Write a sentence to continue" → "Save the
sentence". **Submitted — confirms, never auto-advances.**

**`vote`** — a `<ul>` with `gap:10px`; each option a full-width button,
`border:1px solid; border-radius:8px; padding:18px 20px; gap:16px`.
Unselected: border `rgba(255,255,255,.16)`, transparent background, radio ring
`rgba(255,255,255,.32)`. Selected: border `#EB0B83`, background `rgba(235,11,131,.16)`, ring
and `22×22` dot fill `#EB0B83`. Hover: border → `rgba(255,255,255,.32)`.
Name `19px / 600`; note `15px / rgba(255,255,255,.5)`; tally right-aligned
`15px / 600 / #2CC8E8`. Footnote: *"Everyone votes on their own screen. The room sees the
count, not who voted."* Primary blocked until picked: "Pick one to continue" → "Lock the vote".
**Submitted — confirms.**

**`results`** — two headline stats side by side above a
`border-bottom:1px solid rgba(255,255,255,.16); padding-bottom:22px; margin-bottom:26px`,
divided by a `1px × 52px` hairline: `44px / 600 / -.02em / #2CC8E8` over
`15px / rgba(255,255,255,.5)`. Then a bar list, `gap:16px`; each bar has a label row
(`16px / rgba(255,255,255,.72)` left, `15px / 600 / #2CC8E8` right) and a `height:14px` track
at `rgba(255,255,255,.08)` holding two **square-ended, butt-joined** spans: baseline `#545460`
then growth `#2CC8E8`, the growth span animating `width` from 0 over
`560ms cubic-bezier(.2,0,.2,1)`. No radius, no gridlines, no axes — design-system chart rules.
Closing line: *"Data should inspire a team to decide."* + *"Not have decisions made for them."*
in `#EB0B83`. Primary: "The team has read it". **Confirms.**

**`round`** — the facilitator script callout: `border-left:4px solid #EB0B83;
background:rgba(235,11,131,.16); padding:22px 24px; border-radius:0 8px 8px 0`. Eyebrow
"Facilitator script", then the script at `22px / line-height:1.42 / text-wrap:pretty`. Note
below: *"One lap of the room, no comment, no fixing. Mark it done when the lap closes."*
Primary: "Lap closed". **Confirms.**

---

### 4. Task-complete beat

**Purpose.** Close the loop and hand off to the next task without the user having to hunt for
a control. Replaces the content column (the header and action bar stay).

- `64×6` `#EB0B83` cap, `border-radius:2px`, `margin-bottom:26px`
- `<h2>` "Done." — `46px / 600 / -.01em / line-height:1.08`
- Body `19px / rgba(255,255,255,.72) / max-width:50ch`:
  `"{n}. {title} is closed. {minsLeft} minutes of tasks left in Discover."`
- `border-top:1px solid rgba(255,255,255,.16); padding-top:26px`, then a row:
  - "Up next" eyebrow, next task title at `22px / 600`, its meta at
    `15px / rgba(255,255,255,.5)`
  - **passive kinds only:** "Opening in {n}s" at `15px / rgba(255,255,255,.5)` beside a
    "Hold here" outline button
- Primary becomes `"Open {n}. {next title}"`, or "Close Discover" on the last task

**Pacing rule (the answer to "when a task is finished, what happens?"):**
**auto-advance for passive kinds (`video`, `read`); confirm for anything submitted.** A 3s
countdown (configurable 1–10s) ticks once per second and calls `goTo(idx + 1)` at zero.
"Hold here" clears the interval **and sets a `held` flag** so the countdown line and the Hold
button both disappear, leaving only the primary — do not merely clear the timer, or the UI
freezes at "Opening in 0s".

---

### 5. Task-list slide-over

**Purpose.** The old right-hand TASKS checklist was permanently lit and competed with the
work. It becomes a summoned drawer.

`position:fixed; inset:0; z-index:20; display:flex; justify-content:flex-end`. A scrim button
`flex:1; background:rgba(0,0,0,.6)` closes it (no backdrop blur — the design system forbids
frosted glass). Panel: `width:min(420px,88vw); background:#000;
border-left:1px solid rgba(255,255,255,.16)`, animating
`transform: translateX(100%) → none` over `320ms cubic-bezier(.2,0,.2,1)`.

- Head `padding:22px 24px; border-bottom:1px solid rgba(255,255,255,.16)`: phase-name eyebrow
  over two `white-space:nowrap` spans split by a `1px × 14px` hairline — "3 of 11 done" at
  `rgba(255,255,255,.5)`, "87 min left" at `rgba(255,255,255,.32)` — plus a `34×34` outline
  close button. The head's left block needs `flex:1; min-width:0` or it sizes to its own text
  and the meta wraps mid-number.
- `<ol>` `overflow-y:auto; flex:1`; rows are **single-line and compact**: `padding:10px 20px`,
  `align-items:center`, a `22px` marker, the title at `16px / 600` truncating with
  `text-overflow:ellipsis`, and `{mins} min` right-aligned at `13px / rgba(255,255,255,.32)`.
  **The current task's row carries `background:rgba(255,255,255,.08)`.**

  The compactness is load-bearing: at one line per row, eleven tasks fit the panel with **no
  scrolling at all** (measured 669px of content in a 669px viewport), so "where am I" is
  always answered without auto-scroll machinery. If a phase ever has enough tasks to overflow,
  scroll the current row into view **on open** — and note that the DC runtime fires neither
  `ref` callbacks nor `componentDidUpdate` on the logic class, so in *this* prototype there was
  no hook to do it from; a real React port has both.
- Foot `padding:18px 20px; border-top:1px solid rgba(255,255,255,.16);
  14px / rgba(255,255,255,.32)`: *"The run suggests an order. Any task can be opened out of
  turn."*

---

### 6. Phase-complete summary

`max-width:820px; padding-top:80px`, animated `ritFade`.

**Per-phase, like everything else.** Copy comes from the phase's `close` block
(`{headline, payoff, lede, extra}`); the stats are computed.

- `64×6` `#EB0B83` cap; eyebrow "{phase} closed"
- `<h2>` `46px / 600 / -.01em / line-height:1.08 / text-wrap:pretty`, using the
  statement-then-correction move with the payoff clause in `#EB0B83`. Discover:
  *"The team measured itself and agreed what it is for."* + *"Nothing has changed yet."*
  Empathize: *"The team said out loud what it had only said in confidence."* + *"It has not
  decided anything."*
- Lede `19px / rgba(255,255,255,.72) / max-width:58ch`
- Stat band — `display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr))`,
  `border-top` and `border-bottom` `1px solid rgba(255,255,255,.16)`, cells
  `padding:26px 24px 26px 0`: value `38px / 600 / -.02em / #2CC8E8`, label
  `15px / rgba(255,255,255,.5)`. **All four derive from phase scope** — `{total}/{total}`
  "tasks closed, none skipped", `{gate.of}/{gate.of}` + the gate's own label, the phase's
  `close.extra` stat, and `{sum of mins}` "minutes in the room". Never hand-write these: the
  original hardcoded band claimed 97 minutes for a phase that totals 102.
- `close.extra` is the **one phase-specific slot** and is optional — Discover uses `62` "TeamQ
  score at the start", Empathize `1` "tension named, unattributed". When a phase has no
  distinctive number the band renders three stats rather than padding to four.
- Actions: primary "Open {next phase}" — the next-phase search **skips phases with no tasks**,
  and the button is hidden entirely when none remains, so it never offers to open nothing.
  Then outline "Back to {phase}".

---

## Interactions & Behavior

### Navigation

- **Any task can be opened at any time** from the overview ladder, the drawer, or any segment
  of the progress rail. The run *suggests* an order (via "Next up" / "Ahead" and the resume
  card) but does not enforce it. The one exception is the session hold — see below.
- **Phases are navigable too**: every entry in the phase strip is a button. Built phases open;
  task-less ones are dim and inert. The strip distinguishes two things the original conflated
  — *where the team is* (solid magenta through the current phase, "in the room now") versus
  *what you are viewing* (bright bar, "viewing"). Viewing a phase ahead of the team adds
  "The team is still in Discover. This is a preview."
- Opening a task resets per-task interaction state: `beat:false`, `picked:null`,
  `saved:false`, `held:false`, and closes the drawer.
- Back on the first task, and the header `×`, return to the overview.
- During the completion beat, Back cancels the beat and returns to the task (it does not go to
  the previous task).
- The last task's completion routes to the phase-complete screen instead of a beat.

### Session open/close (Admin and Co-lead)

The session itself is a state the team's leads own, separate from task progress. A strip
below the phase strip on the overview carries it: a status dot (cyan open / muted closed),
the state in plain words, and — **for Admin and Co-lead only** — the control.

| Role | Sees | Can |
| --- | --- | --- |
| Admin | Full strip + control | Open / close the session; work any task ahead of the team |
| Co-lead | Full strip + control | Same as Admin |
| Team member | Strip as read-only status | Open only tasks flagged `prep`; room tasks are held |

When the session is **closed**, a team member gets:
- room tasks in the ladder and drawer marked **HELD**, dimmed to 32% white, `cursor:not-allowed`,
  and `goTo()` refuses them (guard in the navigation function, not just the UI)
- the resume card retitled "Waiting on the session", with the reason underneath — *"This one
  runs with the room. It opens when the Admin or Co-lead opens the session."* — and a blocked
  primary reading "Held until the session opens"
- tasks flagged `prep` still fully open, so individual preparation is never blocked by the
  room not being assembled

When **open**, the strip reads "The session is open to the team", attributed — "Opened by
Admin · all 9 can enter the run on their own screens" — and the control becomes a quiet
outline "Close the session" rather than a second magenta button competing with the run's
primary.

`prep: true` marks a task as doable before the session opens (Discover task 1; Empathize
tasks 1 and 2). Everything else is a room task. **This flag is a content decision** — confirm
which tasks are individual prep against the real data model.

Admin and Co-lead are deliberately identical in permission here; if the real product needs
Co-lead to open but not close (or to require the Admin's session), that is a rule to add.

### The one hard gate

Task 4 (TeamQ+) blocks its primary until `submitted >= 9`, **for facilitators too** — the
facilitator is precisely the role that must be held, so nobody is dropped into results early.
In the prototype "Nudge the two outstanding" sets `submitted: 9`; in production this comes
from the real submission count over a live channel.

Blocked primaries must have label, colour and cursor agree. A magenta pointer button reading
"Held until 9 of 9 have submitted" is a lie.

### Motion

| Where | Value |
| --- | --- |
| Colour / border / background changes | `120ms cubic-bezier(.2,0,.2,1)` |
| Progress-segment fill | `180ms cubic-bezier(.2,0,.2,1)` |
| Screen and task transitions (`ritFade`, `ritIn`, `ritDrawer`) | `320ms cubic-bezier(.2,0,.2,1)` |
| Bars growing from zero (progress fills, result bars) | `560ms cubic-bezier(.2,0,.2,1)` |

Keyframes: `ritFade` (opacity 0 + `translateY(8px)` → none), `ritIn` (opacity 0 +
`translateX(20px)` → none), `ritDrawer` (`translateX(100%)` → none), `ritGrow` (`width:0` →
natural). **No bounce, no spring, no parallax, no entrance animation on type.**

### States

- **Hover.** Filled elements darken (`#EB0B83` → `#C40A6E`). Outlined elements lighten their
  border (16% → 32% white) and take an 8% white wash. Links go `#2CC8E8` → `#5FD8F0`. A CTA
  arrow nudges 3px right. **Never a scale, never a shadow, never an opacity fade to grey.**
- **Press.** The same darkening, held. No shrink, no ripple.
- **Focus.** `border-color:#2CC8E8` plus `box-shadow:0 0 0 3px rgba(44,200,232,.16)` — applied
  via `:focus-visible` on all buttons and links. This is the only glow in the system and it
  exists for accessibility; do not remove it.
- **Disabled.** `background:rgba(255,255,255,.08); color:rgba(255,255,255,.32);
  cursor:not-allowed`, no hover response.

### Responsive

Fluid, not fixed. `max-width` rather than `width`, `minmax(0,1fr)` grid tracks, `flex-wrap` on
header rows. The two-column overview should collapse to one column below roughly 900px. The
runner's content column is `max-width:760px` and centred at all sizes. The rail stays 64px.
Nothing uses viewport units for type.

### Accessibility notes for implementation

The prototype is keyboard-operable (real `<button>`s, visible focus rings) but the following
were out of scope and **must** be added:

- `aria-current="step"` on the active progress segment; `aria-label` per segment
  (`"Task 4 of 11: Launch and take the TeamQ+, not started"`)
- focus moved to the task `<h2>` on task change, and an `aria-live="polite"` announcement of
  the new task
- the drawer as a focus-trapped dialog (`role="dialog"`, `aria-modal`, Escape to close,
  focus restored to the "All tasks" button)
- `aria-disabled` plus an `aria-describedby` reason on blocked primaries
- an `aria-live` region for the auto-advance countdown, and respect for
  `prefers-reduced-motion` (skip auto-advance animation; consider disabling auto-advance
  entirely under that query)

---

## State Management

```
screen        'overview' | 'runner' | 'phasedone'
sessionOpen   boolean     the session is open to the team
openedBy      string|null which role opened it, shown in the strip
phase         number      index into PHASES — which phase is being viewed
idx           number      current task index (0-based) within that phase
done          { [phaseName]: { [taskNumber]: true } }   keyed by phase
gate          { [phaseName]: number }                    gate count per phase
drawerOpen    boolean
beat          boolean     showing the task-complete beat
beatCount     number      auto-advance countdown, seconds
held          boolean     user pressed "Hold here" — suppresses the countdown UI
(gate count is read per phase from `gate`, above)
picked        number|null selected vote option
written       string      the write task's textarea value
saved         boolean     write task saved confirmation
```

Derived (all in `renderVals()` — port these as selectors/computed values):

```
unlockedThrough  index of the first not-done task (drives "Next up" and the resume card)
doneCount        count of done tasks in the viewed phase
pctDone          round(doneCount / total * 100)
minsLeft         sum of mins over not-done tasks
phaseMins        sum of mins over all tasks — every "N min of tasks" total, never hardcoded
gateOpen         submitted >= phase.gate.of
resumeHeld       the resume task is a room task and the session is closed
blocked          per-kind: vote → picked === null
                           write → written.trim().length <= 8
                           gate  → !gateOpen
                           else  → false
primaryLabel     per-kind and per-state (see each variant above)
centerNote       "Then: {n}. {title}" | "Last task in {phase}" | pacing explanation

**Everything user-visible is phase-scoped.** `renderVals()` opens by resolving the viewed
phase and shadowing `done`/`submitted` to that phase's slice, so no downstream line needs to
know which phase it is in. No string in the template says "Discover".
```

Transitions:

| Trigger | Effect |
| --- | --- |
| `beginRun` | `goTo(min(unlockedThrough, total - 1))` |
| `goTo(i)` | `screen:'runner'`, `idx:i`, resets `beat/picked/saved/held`, closes drawer, clears the interval |
| `complete()` | marks done; last task → `screen:'phasedone'`; else `beat:true`, `beatCount:autoSecs`, `held:false`, and for passive kinds starts a 1s interval that calls `goTo(idx+1)` at zero |
| `cancelAuto` | clears the interval and sets `held:true` |
| primary during beat | `goTo(idx + 1)` |
| `closeRun` | clears the interval, `screen:'overview'` |
| `toggleSession` | flips `sessionOpen`; stamps `openedBy` with the acting role on open, clears it on close |

**Always clear the countdown interval** on unmount, on `goTo`, and on `closeRun` — a leaked
interval will yank the user out of a task they navigated to deliberately.

### Props (design-time switches — decide what becomes real config)

| Prop | Type | Default | Meaning |
| --- | --- | --- | --- |
| `role` | `'Admin' \| 'Co-lead' \| 'Team member'` | `Admin` | Who is looking. Admin and Co-lead can open/close the session and release the gate; Team member cannot, and is held out of room tasks while the session is closed. In production this is derived from the person's role on the session, not a user toggle. |
| `autoAdvance` | boolean | `true` | Master switch for passive-task auto-advance. Consider surfacing as a user preference and forcing it off under `prefers-reduced-motion`. |
| `autoAdvanceSeconds` | number 1–10 | `3` | Countdown length. |

### Data contract the UI needs

```
Phase  { name, tasks: Task[], intro, introMeta,
         gate:  { label, verb, waiting, of },
         close: { headline, payoff, lede, extra?: { value, label } } }
Task   { n, title, kind, who, mins, body, prep?,
         mediaNote?, script?, fieldLabel?, placeholder?,
         readTitle?, readLead?, readTail? }
kind   'video' | 'read' | 'gate' | 'write' | 'vote' | 'results' | 'round'
Person { name, submitted: boolean, isSelf: boolean }
Option { name, note, tally }
Bar    { name, score, basePct, growPct }
```

`kind` is the switch the runner renders from — the only truly load-bearing field. `who` and
`mins` feed the kicker, the ladder meta and the `minsLeft` maths.

---

## Design Tokens

Copied verbatim into `design/tokens/`. Prefer the codebase's existing token layer if it
already carries these; otherwise import these files. Full ramps are in `colors.css` — the
subset the runner actually uses:

**Colours**

| Token | Value | Job |
| --- | --- | --- |
| `--ink-1000` | `#000000` | the ground, everywhere |
| `--ink-950` | `#0A0A0B` | sunken surfaces (video well, textarea) |
| `--ink-900` | `#121214` | the one dark container surface |
| `--ink-800` | `#1C1C20` | avatar fill |
| `--ink-500` | `#545460` | chart baseline bar; muted ink on white cards |
| `--white` | `#FFFFFF` | primary text (the app chrome has no white surfaces) |
| `--magenta-500` | `#EB0B83` | **names the topic** — eyebrows, caps, rules, primary buttons |
| `--magenta-600` | `#C40A6E` | filled hover |
| `--cyan-500` | `#2CC8E8` | **carries the data** — stats, deltas, growth bars, links |
| `--cyan-400` | `#5FD8F0` | link hover |
| `--white-a72` | `rgba(255,255,255,.72)` | secondary text |
| `--white-a50` | `rgba(255,255,255,.50)` | muted text |
| `--white-a32` | `rgba(255,255,255,.32)` | captions, disabled ink |
| `--white-a16` | `rgba(255,255,255,.16)` | **the hairline** |
| `--white-a08` | `rgba(255,255,255,.08)` | hover wash, empty track, disabled fill |
| `--magenta-a16` / `--magenta-a28` | `rgba(235,11,131,.16)` / `.28` | callout wash, current segment |
| `--cyan-a16` | `rgba(44,200,232,.16)` | the focus ring |

Never swap magenta and cyan. Never add a third UI accent.

**Type.** One family, no second face:
`--font-core: 'Source Sans 3','Source Sans Pro',-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif`
(self-hosted woff2 via `tokens/fonts.css`; the product's declared fallback is Arial).
Weights 400 / 600 / 700 only — hierarchy comes from weight, size and colour.

| Role | Size | Weight | Tracking |
| --- | --- | --- | --- |
| Beat / phase-close headline | 46px | 600 | -.01em |
| Task title | 40px | 600 | -.01em |
| Big stat | 44px | 600 | -.02em |
| Page title | 34px | 600 | -.01em |
| Gate count / phase-close stat | 32 / 38px | 600 | -.02em |
| Panel stat | 26px | 600 | — |
| Callout / script body | 22px | 400 | — |
| Lede | 19px | 400 | — |
| Body, resume headline | 17–19px | 400–600 | — |
| Ladder title | 18px | 600 | — |
| UI label, meta | 14–16px | 400–600 | — |
| Eyebrow | 12–13px | 600 | **.22em, uppercase — do not reduce** |
| Caption, version | 11–14px | 400 | — |

Line height 1.5 body, 1.08–1.15 headlines, 1.42–1.55 callouts and card prose. `text-wrap:
pretty` on every multi-line prose block. No text below 14px.

**Spacing.** 4px scale. Page padding `34–40px` vertical / `40–48px` horizontal. Grid gap 48px.
Card padding 22px. Card gap 24px. Section rhythm 26 / 32 / 38–44px.

**Radius.** `0` bars and rules · `4px` controls and buttons · `8px` dark containers ·
`12px` artefact cards and photographs (documents only — not used in the app) ·
`50%` markers and avatars.
**No pill buttons** — the brand does not use them.

**Rules.** Four weights only: `1px` hairline at 16% white · `2px` magenta connectors ·
`4px` magenta callout/quote rule · `6px` magenta artefact cap.

**Shadow.** None. On black, elevation is surface lightness, not shadow. The focus ring is the
sole exception.

---

## Assets

| Asset | Source | Notes |
| --- | --- | --- |
| `design/assets/samuh-wordmark-white.png` | Samuh Design System `assets/logo/` | 515×191 raster, extracted from the case-study deck. **No vector supplied — request an SVG.** Legible to ~104px wide; used only in the overview header. |
| Left-rail, close, back, next, play, check icons | **Hand-written for this prototype** | 1.5px-stroke outline SVG paths, flagged substitution. Replace with the codebase's icon set. |
| Token CSS (`design/tokens/*.css`) | Samuh Design System, verbatim | Colours, type, spacing, shape, base, `@font-face`. |
| `assets/logo/samuh-wordmark-white.png` | Samuh Design System | Must sit at this exact path — `Wordmark` resolves `assetBase + 'assets/logo/…'`. |
| Source Sans 3 woff2 | Samuh Design System `assets/fonts/` | **Not bundled here** — `tokens/fonts.css` references them. Copy from the design system or serve from the app's own font pipeline. |

No photography or illustration is used. The design system's hand-drawn workshop artefacts and
session photograph are document imagery and were deliberately left out of the app chrome — if
imagery is wanted later, use those, never stock or generated illustration.

---

## Files

| Path | What it is |
| --- | --- |
| `design/Ritualizer Redesign.dc.html` | The prototype. Read the `class Component` block for the state machine and the template for layout/styling. Not portable — recreate, don't copy. |
| `design/tokens/colors.css` | Full ink ramp, brand accents, alpha washes, semantic roles. |
| `design/tokens/typography.css` | Family, weights, web and slide type scales, tracking. |
| `design/tokens/spacing.css` | 4px spacing scale. |
| `design/tokens/shape.css` | Radii, rule weights, motion durations and easing. |
| `design/tokens/base.css` | Element defaults. |
| `design/tokens/fonts.css` | `@font-face` rules for Source Sans 3. |
| `design/assets/samuh-wordmark-white.png` | The wordmark. |

## Suggested build order

1. Token layer + the shell (rail, header, phase strip) — everything else sits inside it.
2. Phase overview with real task data from the API, driven by a phase list — **build it
   multi-phase from the start**; the prototype proves the shape with Discover and Empathize.
   Confirm the task lists and kinds against the codebase before going further; the content in
   this bundle is placeholder.
3. The runner shell: sticky header, progress rail, content column, fixed action bar. Route it
   (`/journey/:phase/run/:taskIndex`) so tasks are addressable and browser-back works.
4. Task kinds, cheapest first: `round` → `read` → `video` → `write` → `vote` → `results` →
   `gate` (the gate needs the live submission channel).
5. The completion beat and the pacing rule (passive auto-advances, submitted confirms),
   including the `held` flag and interval cleanup.
6. The slide-over, then the phase-complete summary.
7. Accessibility pass per the list above — do not defer this past step 7.

## Open questions for the team

1. The Discover and Empathize task lists — kinds, durations, copy — confirm against the real
   data model. Everything in this bundle is reconstructed from screenshots.
2. Do the other four phases use the same seven task kinds, or does any phase need an eighth?
   And what are their gate stats and `close.extra` numbers, if any?
3. Where does the submission count for the gate come from, and is it live (websocket/poll) or
   refreshed on view? The session-open state needs the same channel — a member sitting on a
   held task should see it unlock without reloading.
4. Do Admin and Co-lead have identical session powers, or should Co-lead be able to open but
   not close? The design currently treats them as equal.
5. Which tasks are individual prep (`prep: true`) versus room tasks? The design guesses from
   each task's `who` string; the real model should say so explicitly.
6. Should auto-advance be a user preference rather than a build-time default?
7. Is there an existing icon set in `samuh-dashboard`? If not, this needs a decision before
   the rail ships — it is the last hand-drawn element in the design.
8. Does `samuh-dashboard` already consume the Samuh Design System package? If so, import
   `Button`/`Eyebrow`/`StatBlock`/`Callout`/`Badge`/`Wordmark`/`CompareBar` from it directly
   rather than re-implementing the table above.
